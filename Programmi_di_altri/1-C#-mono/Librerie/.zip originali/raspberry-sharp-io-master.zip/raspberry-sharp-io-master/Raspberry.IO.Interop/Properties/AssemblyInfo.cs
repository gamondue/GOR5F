﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Raspberry.IO.Interop")]
[assembly: AssemblyDescription("Raspberry Pi Interoperability library")]
[assembly: AssemblyConfiguration("")]
[assembly: Guid("dfdae73d-4511-4e8b-a7c3-e36b32266955")]


