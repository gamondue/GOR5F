﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Raspberry.IO.Components")]
[assembly: AssemblyDescription("Raspberry Pi IO Components")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("4fa05c29-4c49-48c9-a04c-7edfcd3dd944")]
