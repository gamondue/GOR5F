namespace Raspberry.IO.Components.Sensors.Temperature.Dht
{
    public class DhtData
    {
        public decimal Temperature;
        public decimal Humidity;
    }
}