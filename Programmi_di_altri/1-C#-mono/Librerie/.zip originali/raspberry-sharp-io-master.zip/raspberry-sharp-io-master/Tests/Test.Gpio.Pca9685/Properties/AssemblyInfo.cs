﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Test.Gpio.Pca9685")]
[assembly: AssemblyDescription("Raspberry Pi Pca9685 Component Sample")]
[assembly: AssemblyConfiguration("")]
