pi_sensors
==========

This project has some working code for communicating with a VCNL4000 with a Raspberry PI using Mono / .NET

It has some code for communicating with a ADS1115 16-bit ADC - I am not sure how well this works :-(
