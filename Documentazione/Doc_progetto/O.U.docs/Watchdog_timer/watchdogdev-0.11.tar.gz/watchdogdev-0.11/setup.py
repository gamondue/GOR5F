#!/usr/bin/env python
from distutils.core import setup, Extension

execfile('setup_common.py')
