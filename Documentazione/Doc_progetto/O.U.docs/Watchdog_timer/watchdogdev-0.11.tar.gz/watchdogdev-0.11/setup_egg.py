#!/usr/bin/env python
import ez_setup
ez_setup.use_setuptools()
from setuptools import setup, Extension

execfile('setup_common.py')
